import os

# إعدادات البوت والتوكن
BOT_TOKEN = "7865251536:AAGNPCF-YXAe8Y0T8rhGnnRJFy7_f9NWnAI"
API_ID = "22004639"
API_HASH = "bc9b7c9b66e1dd9e046825a53cd623c2"
SERVER_PORT = "8081"

# مسارات السيرفر (مهمة جداً)
SERVER_BIN_PATH = os.path.expanduser("~/telegram-bot-api/build/telegram-bot-api")
TERMUX_HOME = os.path.expanduser("~")
# مكان حفظ بيانات السيرفر بأمان
SERVER_WORK_DIR = os.path.join(TERMUX_HOME, "bot_server_data_safe")

# مسارات المشروع الحالية
BASE_DIR = os.getcwd()
DOWNLOADS_DIR = os.path.join(BASE_DIR, "downloads")
LOG_FILE = os.path.join(BASE_DIR, "bot.log")

# رابط الاتصال المحلي
LOCAL_API_URL = f"http://127.0.0.1:{SERVER_PORT}/bot"