import os
import sys
import logging
import asyncio
# تقليل الاستيرادات غير الضرورية عند البدء
from telegram.ext import (
    ApplicationBuilder, 
    MessageHandler, 
    CallbackQueryHandler, 
    filters
)
import config
from core import server
from handlers import commands, messages, callbacks

# إعداد اللوغ الصامت جداً
LOG_FILE = "session_errors.log"
logging.basicConfig(
    filename=LOG_FILE,
    filemode='w', 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.ERROR
)

def print_banner():
    # تنظيف الشاشة مرة واحدة فقط
    os.system('clear')
    print("\033[1;36m")
    print("╔════════════════════════════════════════╗")
    print("║       🚀 MegaBot (Ultra Fast) ⚡       ║")
    print("╚════════════════════════════════════════╝")
    print("\033[0m")

def main():
    print_banner()
    
    if not os.path.exists(config.DOWNLOADS_DIR): os.makedirs(config.DOWNLOADS_DIR)
    
    # تشغيل السيرفر (النسخة السريعة)
    server_proc = server.start_server()
    
    try:
        # بناء التطبيق بسرعة
        app = ApplicationBuilder().token(config.BOT_TOKEN)\
            .base_url(config.LOCAL_API_URL)\
            .read_timeout(100).write_timeout(100).connect_timeout(100)\
            .pool_timeout(100).get_updates_read_timeout(100)\
            .build()
        
        # إضافة المعالجات
        app.add_handler(MessageHandler(filters.COMMAND & filters.Regex("^/start$"), commands.start))
        app.add_handler(MessageHandler(filters.COMMAND & filters.Regex("^/help$"), commands.help_command))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, messages.handle_url))
        app.add_handler(CallbackQueryHandler(callbacks.handle_button))
        
        print("🤖 \033[1;34mتم التشغيل! أرسل /start الآن.\033[0m")
        
        # البدء فوراً
        app.run_polling()
        
    except Exception as e:
        logging.error(f"Critical: {e}")
    finally:
        try: server_proc.kill()
        except: pass

if __name__ == "__main__":
    main()