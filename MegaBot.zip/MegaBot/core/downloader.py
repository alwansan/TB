import sys
import yt_dlp
import asyncio
import time
import requests
from utils import ui

def get_info(url):
    opts = {'quiet': True, 'no_warnings': True, 'check_formats': False}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)
    except: return None

# --- Hooks (كما هي) ---
def create_telegram_hook(context, chat_id, msg_id, session_id, main_loop, last_update_time):
    tick = 0
    last_update_time[session_id] = 0
    def telegram_progress_hook(d):
        nonlocal tick
        if d['status'] == 'downloading':
            now = time.time()
            if (now - last_update_time.get(session_id, 0) > 1.0):
                text = ui.get_telegram_dl_msg(d, tick)
                try:
                    asyncio.run_coroutine_threadsafe(
                        context.bot.edit_message_text(chat_id, msg_id, text, parse_mode="Markdown"),
                        main_loop
                    )
                except: pass
                last_update_time[session_id] = now
                tick += 1
    return telegram_progress_hook

def terminal_progress_hook(d):
    if d['status'] == 'downloading':
        ui.print_termux_bar(d)
    elif d['status'] == 'finished':
        sys.stdout.write(f"\r\033[K✅ {ui.C_GREEN}Download Complete!{ui.C_RESET}\n")
        sys.stdout.flush()

# --- محمل الصور السريع (جديد) ---
async def download_image_direct(url, path, loop):
    """تحميل الصور باستخدام requests (أسرع من yt-dlp)"""
    def _download():
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            r = requests.get(url, headers=headers, stream=True)
            if r.status_code == 200:
                with open(path, 'wb') as f:
                    for chunk in r.iter_content(1024):
                        f.write(chunk)
                return True
        except: return False
        return False

    return await loop.run_in_executor(None, _download)

async def download_video(url, path, format_req, telegram_hook, loop, is_direct=False):
    # إذا كان الطلب صورة، نستخدم المحمل الخاص
    if format_req == 'image_direct':
        success = await download_image_direct(url, path, loop)
        if not success:
            raise Exception("Image download failed")
        return

    # إعدادات yt-dlp للفيديو
    opts = {
        'outtmpl': path,
        'quiet': True,
        'noprogress': True,
        'no_warnings': True,
        'progress_hooks': [telegram_hook, terminal_progress_hook],
        'buffersize': 1024 * 1024 * 50, 
        'http_chunk_size': 10485760,
        'concurrent_fragment_downloads': 8,
        'no_check_certificate': True,
    }

    if is_direct:
        pass # الرابط المباشر لا يحتاج format
    elif format_req == 'audio':
        opts.update({'format': 'bestaudio/best', 'postprocessors': [{'key': 'FFmpegExtractAudio','preferredcodec': 'mp3'}]})
    elif format_req == 'best':
        opts.update({'format': 'bestvideo+bestaudio/best', 'merge_output_format': 'mp4'})
    else:
        try:
            h = int(format_req)
            opts.update({'format': f'bestvideo[height<={h}]+bestaudio/best[height<={h}]/best'})
        except:
            opts.update({'format': 'bestvideo+bestaudio/best'})
            
    if format_req != 'audio': opts['merge_output_format'] = 'mp4'

    await loop.run_in_executor(None, lambda: yt_dlp.YoutubeDL(opts).download([url]))