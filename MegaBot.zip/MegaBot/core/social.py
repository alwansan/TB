import yt_dlp
import requests
import re
from utils import formatting

# رؤوس متصفح حقيقية لتجنب الحظر
FAKE_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
}

class SocialExtractor:
    
    @staticmethod
    def get_tiktok(url):
        """مستخرج تيك توك (بدون علامة مائية + صور)"""
        opts = {
            'quiet': True,
            'no_warnings': True,
            'http_headers': FAKE_HEADERS,
            # استخراج النسخة الأصلية
            'format': 'best', 
            'noplaylist': True,
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                
                # التحقق هل هو فيديو أم صور
                # تيك توك الصور ياتي كـ playlist
                if info.get('_type') == 'playlist':
                    return {
                        'type': 'gallery',
                        'title': info.get('title', 'TikTok Slideshow'),
                        'count': len(info.get('entries', [])),
                        'extractor': 'TikTok (Images)'
                    }
                
                return {
                    'type': 'video',
                    'title': info.get('title', 'TikTok Video'),
                    'duration': info.get('duration', 0),
                    'filesize': info.get('filesize') or 5000000, # تقدير 5MB
                    'url': info.get('url'), # الرابط المباشر
                    'extractor': 'TikTok (No-WM)'
                }
        except Exception as e:
            print(f"TikTok Error: {e}")
            return None

    @staticmethod
    def get_instagram(url):
        """مستخرج انستقرام (ريلز + صور)"""
        # انستقرام صعب جداً، نعتمد على yt-dlp المحدث مع Headers
        opts = {
            'quiet': True,
            'no_warnings': True,
            'http_headers': FAKE_HEADERS,
            'noplaylist': True, # إلا إذا كان بوست متعدد
            'extract_flat': False,
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                
                # اكتشاف الصور
                if info.get('_type') == 'playlist' or not info.get('vcodec'):
                    # غالباً صورة
                    return {
                        'type': 'image',
                        'title': info.get('title', 'Instagram Post'),
                        'extractor': 'Instagram (Photo)',
                        'url': info.get('url') or info['entries'][0]['url']
                    }
                
                # فيديو / ريلز
                return {
                    'type': 'video',
                    'title': info.get('title', 'Instagram Reel'),
                    'duration': info.get('duration', 0),
                    'filesize': info.get('filesize') or 10000000,
                    'url': info.get('url'),
                    'extractor': 'Instagram (Reels)'
                }
        except: return None

    @staticmethod
    def get_twitter(url):
        """مستخرج تويتر/X (أعلى جودة)"""
        opts = {'quiet': True, 'http_headers': FAKE_HEADERS}
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                return {
                    'type': 'video',
                    'title': info.get('title', 'X Video')[:50],
                    'duration': info.get('duration', 0),
                    'filesize': info.get('filesize') or 5000000,
                    'url': info.get('url'),
                    'extractor': 'X / Twitter'
                }
        except: return None

def router(url):
    """الموجه الذكي: يختار المستخرج حسب الرابط"""
    if "tiktok.com" in url:
        return SocialExtractor.get_tiktok(url)
    elif "instagram.com" in url:
        return SocialExtractor.get_instagram(url)
    elif "twitter.com" in url or "x.com" in url:
        return SocialExtractor.get_twitter(url)
    
    return None # ليس موقع سوشيال ميديا معروف، نعود للنظام العام