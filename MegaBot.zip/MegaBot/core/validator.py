import yt_dlp
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

def is_supported(url):
    """
    تحقق سريع جداً مما إذا كان الرابط مدعوماً
    بدون استخراج المعلومات الكاملة
    """
    # 1. فحص الاتصال (Ping)
    try:
        req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urlopen(req, timeout=5) as response:
            pass # الموقع يعمل
    except (HTTPError, URLError):
        return False, "❌ لا يمكن الوصول للموقع (قد يكون محجوباً أو معطلاً)."
    except ValueError:
        return False, "❌ رابط غير صحيح."

    # 2. فحص الدعم في yt-dlp
    # نستخدم extractors الداخلي للفحص دون تحميل
    extractors = yt_dlp.extractor.gen_extractors()
    for e in extractors:
        if e.suitable(url) and e.IE_NAME != 'generic':
            return True, "Supported"
            
    # Generic يعني يحاول التحميل من أي موقع، نقبله لكن بحذر
    return True, "Generic"