import os
import sys
import time
import shutil
import subprocess
import socket
import config

def check_binary():
    return os.path.exists(config.SERVER_BIN_PATH)

def wait_for_port(port, timeout=5.0):
    """
    فحص ذكي: يحاول الاتصال بالمنفذ كل 0.1 ثانية
    بمجرد أن يفتح المنفذ، يعود فوراً (لا ينتظر 5 ثواني)
    """
    start_time = time.time()
    while time.time() - start_time < timeout:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.1):
                return True
        except (socket.timeout, ConnectionRefusedError):
            time.sleep(0.1) # انتظار قصير جداً والمحاولة مجدداً
    return False

def start_server():
    # 1. تنظيف فوري (بدون انتظار طويل)
    subprocess.call(["pkill", "-9", "-f", "telegram-bot-api"], stderr=subprocess.DEVNULL)
    
    # تنظيف المجلدات بسرعة
    if os.path.exists(config.SERVER_WORK_DIR):
        try: shutil.rmtree(config.SERVER_WORK_DIR)
        except: pass
    os.makedirs(config.SERVER_WORK_DIR, exist_ok=True)

    if not check_binary():
        print(f"❌ ملف السيرفر غير موجود!")
        sys.exit(1)

    print(f"🚀 \033[1;33mإطلاق السيرفر...\033[0m", end=" ", flush=True)
    
    # تشغيل السيرفر
    proc = subprocess.Popen(
        [
            config.SERVER_BIN_PATH,
            "--api-id", config.API_ID,
            "--api-hash", config.API_HASH,
            "--local",
            "--http-port", config.SERVER_PORT,
            "--dir", config.SERVER_WORK_DIR,
            "--temp-dir", config.SERVER_WORK_DIR,
            "--verbosity", "0" # صامت تماماً لزيادة السرعة
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    
    # 🔥 هنا السرعة: ننتظر المنفذ أن يفتح بدلاً من النوم 5 ثواني
    if wait_for_port(int(config.SERVER_PORT)):
        print("✅ \033[1;32mجاهز! (0.5s)\033[0m")
        return proc
    else:
        print("\n❌ فشل السيرفر في النهوض!")
        proc.kill()
        sys.exit(1)