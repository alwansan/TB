import yt_dlp
from utils import formatting

def get_info_fast(url):
    # رؤوس تمويه قوية (تجعل البوت يبدو كمتصفح كروم حقيقي)
    # هذا يحل مشكلة انستقرام وتيكتوك
    fake_headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Sec-Fetch-Mode': 'navigate',
    }

    opts = {
        'quiet': True,
        'no_warnings': True,
        'geo_bypass': True,
        'skip_download': True,
        
        # تفعيل فحص الروابط لليوتيوب فقط (للدقة)
        'check_formats': 'youtube' in url.lower(),
        
        # تمرير الرؤوس الوهمية
        'http_headers': fake_headers,
        
        # السماح باستخراج قوائم التشغيل (للصور المتعددة في انستا)
        'extract_flat': 'in_playlist', 
    }
    
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # --- معالجة الصور والستوريات ---
            # إذا كان الرابط يحتوي على صور (Gallery)، yt-dlp يرجع نوع 'playlist'
            if info.get('_type') == 'playlist' and not info.get('formats'):
                # هذه غالباً صور انستقرام أو تويتر
                entries = list(info.get('entries', []))
                if entries:
                    # نأخذ أول عنصر كعينة
                    info = entries[0]
                    info['is_gallery'] = True
                    info['gallery_count'] = len(entries)

            title = info.get('title', 'Media Content')
            duration = info.get('duration', 0)
            extractor = info.get('extractor_key', 'Web')
            
            clean_formats = []
            seen_heights = set()
            raw_formats = info.get('formats', [])

            # --- 1. حالة الصور (No Formats) ---
            # إذا لم نجد صيغ فيديو، ولكن يوجد رابط مباشر (url)، فهذه غالباً صورة
            if not raw_formats and info.get('url'):
                ext = info.get('ext', 'jpg')
                clean_formats.append({
                    'format_id': 'image',
                    'height': 0, # لا يوجد ارتفاع للفيديو
                    'filesize': 0, # حجم غير معروف
                    'note': f"Image ({ext})",
                    'is_image': True
                })

            # --- 2. معالجة الفيديو (Youtube, TikTok, FB...) ---
            # (نفس الخوارزمية الذكية السابقة لحساب الحجم)
            
            # البحث عن أفضل صوت
            max_audio_size = 0
            for f in raw_formats:
                if f.get('vcodec') == 'none' and f.get('acodec') != 'none':
                    s = f.get('filesize') or f.get('filesize_approx') or 0
                    if s == 0 and duration and f.get('abr'):
                        s = (f.get('abr') * 1024 * duration) / 8
                    if s > max_audio_size: max_audio_size = s

            # معالجة الفيديو
            raw_formats.sort(key=lambda x: (x.get('height') or 0), reverse=True)

            for f in raw_formats:
                h = f.get('height')
                # نقبل أي ارتفاع الآن (حتى لو صغير للتيك توك)
                if not h: continue 
                
                if f.get('vcodec') != 'none':
                    video_size = f.get('filesize') or f.get('filesize_approx') or 0
                    
                    if video_size == 0 and duration:
                        bitrate = f.get('tbr') or f.get('vbr') or 1000
                        video_size = (bitrate * 1024 * duration) / 8
                    
                    final_size = 0
                    if f.get('acodec') == 'none':
                        if video_size > 0: final_size = video_size + max_audio_size
                    else:
                        final_size = video_size

                    if final_size > 0:
                        if h not in seen_heights:
                            seen_heights.add(h)
                            clean_formats.append({
                                'format_id': f['format_id'],
                                'height': h,
                                'filesize': int(final_size),
                                'tbr': f.get('tbr', 0),
                                'is_image': False
                            })

            return {
                'title': title,
                'duration': duration,
                'formats': clean_formats,
                'extractor_key': extractor,
                'is_gallery': info.get('is_gallery', False)
            }

    except Exception as e:
        print(f"Extractor Error: {e}")
        return None