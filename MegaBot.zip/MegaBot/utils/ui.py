import sys
import re
import math
import time

# ألوان تيرمكس
C_RESET  = "\033[0m"
C_GREEN  = "\033[1;32m"
C_YELLOW = "\033[1;33m"
C_BLUE   = "\033[1;34m"
C_CYAN   = "\033[1;36m"
C_RED    = "\033[1;31m"

SPINNERS = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

def clean_ansi(text):
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def get_percentage(d):
    try:
        p = d.get('_percent_str', '').replace('%', '')
        return float(clean_ansi(p))
    except: return 0.0

def make_progress_bar(percentage):
    """رسم شريط موحد (بلوكات)"""
    total = 10
    # ضمان أن النسبة لا تتجاوز 100 ولا تقل عن 0
    if percentage > 100: percentage = 100
    if percentage < 0: percentage = 0
    
    filled = int(total * percentage // 100)
    bar = '▰' * filled + '▱' * (total - filled)
    return bar

# --- شريط تيرمكس ---
def print_termux_bar(d):
    per = get_percentage(d)
    bar = make_progress_bar(per).replace('▰', '━').replace('▱', '─') # تحويل الرموز لتناسب التيرمينال
    
    speed = clean_ansi(d.get('_speed_str', '0B/s')).strip()
    size = clean_ansi(d.get('_total_bytes_str', '')).strip()
    if not size: size = "..."
    
    sys.stdout.write(
        f"\r\033[K{C_BLUE}⬇️ DL:{C_RESET} [{C_GREEN}{bar}{C_RESET}] {C_YELLOW}{per:5.1f}%{C_RESET} "
        f"📦 {size} 🚀 {C_CYAN}{speed}{C_RESET}"
    )
    sys.stdout.flush()

def print_termux_upload(percent):
    bar = make_progress_bar(percent).replace('▰', '━').replace('▱', '─')
    sys.stdout.write(
        f"\r\033[K{C_RED}⬆️ UP:{C_RESET} [{C_GREEN}{bar}{C_RESET}] {C_YELLOW}{percent:.1f}%{C_RESET} 🚀 Local Server"
    )
    sys.stdout.flush()

# --- رسالة البداية ---
def get_startup_msg():
    bar = '▱' * 10
    return (
        f"📥 **Downloading Video...** ⠋\n"
        f"`Establishing Connection...`\n\n"
        f"`{bar}` **0.0%**\n\n"
        f"📦 **Size:** `Calculating...`\n"
        f"🚀 **Speed:** `Starting...`\n"
        f"⏳ **ETA:** `...`"
    )

# --- رسالة التحميل (Download) ---
def get_telegram_dl_msg(d, tick):
    per = get_percentage(d)
    spinner = SPINNERS[tick % len(SPINNERS)]
    bar = make_progress_bar(per)
    
    size = clean_ansi(d.get('_total_bytes_str', '...')).strip()
    speed = clean_ansi(d.get('_speed_str', '...')).strip()
    eta = clean_ansi(d.get('_eta_str', '...')).strip()
    
    return (
        f"📥 **Downloading Video...** {spinner}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"`{bar}` **{per:.1f}%**\n\n"
        f"📦 **Size:** `{size}`\n"
        f"🚀 **Speed:** `{speed}`\n"
        f"⏳ **ETA:** `{eta}`"
    )

# --- رسالة الرفع (Upload) - التصميم الجديد المطابق ---
def get_telegram_ul_msg(percent, tick):
    spinner = SPINNERS[tick % len(SPINNERS)]
    bar = make_progress_bar(percent)
    
    return (
        f"📤 **Uploading Video...** {spinner}\n"
        f"➖➖➖➖➖➖➖➖➖➖\n"
        f"`{bar}` **{percent:.1f}%**\n\n"
        f"⚡ **Source:** `Local Server`\n"
        f"👤 **To:** `User`\n"
        f"🚀 **Status:** `Processing...`"
    )