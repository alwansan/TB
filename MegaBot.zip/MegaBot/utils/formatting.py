import math

def format_size(size_bytes):
    if not size_bytes: return "Unknown"
    size_name = ("B", "KB", "MB", "GB", "TB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    return "%s %s" % (round(size_bytes / p, 2), size_name[i])

def make_progress_bar(percentage):
    """شريط التحميل (للتنزيل)"""
    total = 12
    filled = int(total * percentage // 100)
    bar = '▰' * filled + '▱' * (total - filled)
    return bar

def format_time(seconds):
    if not seconds: return "0:00"
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0: return f"{int(h)}:{int(m):02d}:{int(s):02d}"
    return f"{int(m)}:{int(s):02d}"

def get_spin_frame(tick):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    return frames[tick % len(frames)]

def get_scanner_bar(tick):
    """شريط سكانر متحرك (للرفع)"""
    # حركة كتلة تتحرك يمين ويسار
    width = 12
    pos = tick % (width * 2)
    if pos >= width:
        pos = (width * 2) - pos - 1
    
    # بناء الشريط
    chars = ['▱'] * width
    if 0 <= pos < width:
        chars[pos] = '▰' # الرأس المتحرك
        if pos > 0: chars[pos-1] = '▰' # ذيل صغير
    
    return "".join(chars)