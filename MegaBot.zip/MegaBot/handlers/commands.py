from telegram import Update
from telegram.ext import ContextTypes

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user.first_name
    await update.message.reply_text(
        f"👋 **أهلاً بك يا {user} في البوت العملاق!** 🤖\n\n"
        "📥 **أنا هنا لتحميل كل شيء:**\n"
        "🔹 فيديوهات **Youtube** (حتى 4K)\n"
        "🔹 ريلز **Facebook & Instagram**\n"
        "🔹 مقاطع **TikTok** (بدون علامة مائية)\n\n"
        "💪 **مميزاتي:**\n"
        "✅ أدعم ملفات بحجم **2GB**\n"
        "✅ سيرفر محلي فائق السرعة\n"
        "✅ تحويل تلقائي إلى **MP3**\n\n"
        "🚀 **فقط أرسل الرابط وشاهد السحر!**",
        parse_mode="Markdown"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🆘 **مركز المساعدة**\n\n"
        "1️⃣ انسخ رابط الفيديو.\n"
        "2️⃣ الصقه هنا في المحادثة.\n"
        "3️⃣ انتظر قليلاً واختر الجودة.\n\n"
        "⚠️ **ملاحظة:** تأكد أن الفيديو 'عام' (Public) وليس خاصاً.",
        parse_mode="Markdown"
    )