import uuid
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from core import downloader, fast_extractor, social # استيراد الكور الجديد
from utils import formatting, state

async def handle_url(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text.strip()
    if not url.startswith(("http", "www")):
        await update.message.reply_text("❌ **رابط غير صحيح**", parse_mode="Markdown")
        return

    msg = await update.message.reply_text("🔎 **جاري التعرف على الموقع...**")
    loop = asyncio.get_event_loop()
    
    # 1. فحص هل هو سوشيال ميديا؟ (Insta, TikTok, Twitter)
    social_info = await loop.run_in_executor(None, social.router, url)
    
    if social_info:
        # --- مسار السوشيال ميديا ---
        title = social_info.get('title', 'Social Media')[:50]
        extractor = social_info.get('extractor', 'Social')
        
        session_id = str(uuid.uuid4())[:8]
        state.temp_data[session_id] = {'url': url, 'title': title}
        
        # حفظ الرابط المباشر إذا وجد (للسرعة)
        if social_info.get('url'):
            state.direct_links[session_id] = {'best': social_info['url']}
        
        keyboard = []
        
        if social_info['type'] == 'image' or social_info['type'] == 'gallery':
            # زر تحميل الصور
            # إذا كان الرابط مباشراً، نحفظه
            if social_info.get('url'):
                state.direct_links[session_id] = {'image_direct': social_info['url']}
                keyboard.append([InlineKeyboardButton("📸 Download Photo", callback_data=f"{session_id}|image_direct|Photo")])
            else:
                # إذا كان معرض (Gallery)، نترك yt-dlp يتعامل معه
                keyboard.append([InlineKeyboardButton("📸 Download Gallery", callback_data=f"{session_id}|image|Gallery")])
                
        else:
            # فيديو
            size_str = formatting.format_size(social_info.get('filesize', 0))
            keyboard.append([InlineKeyboardButton(f"📹 Download Video ({size_str})", callback_data=f"{session_id}|best|Video")])
            keyboard.append([InlineKeyboardButton("🎵 Audio Only", callback_data=f"{session_id}|audio|Audio")])

        text_msg = (
            f"🎬 **{title}**\n"
            f"⚡ **Source:** `{extractor}`\n"
            f"👇 **Media Ready:**"
        )
        await msg.edit_text(text_msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown")
        return

    # 2. إذا لم يكن سوشيال، نستخدم المسار العادي (Pornhub, Youtube...)
    # (نفس الكود السابق للمواقع العامة)
    info = await loop.run_in_executor(None, fast_extractor.get_info_fast, url)
    if not info:
        info = await loop.run_in_executor(None, downloader.get_info, url)

    if not info:
        await msg.edit_text("❌ **فشل التحليل!** الرابط غير مدعوم أو خاص.")
        return

    title = info.get('title', 'Video')[:60]
    duration = formatting.format_time(info.get('duration'))
    extractor = info.get('extractor_key', 'Web')
    
    keyboard = []
    seen = set()
    qualities = []
    
    # معالجة القائمة (نفس السابق)
    raw_formats = info.get('formats', [])
    if not raw_formats and info.get('duration'):
         dur = info.get('duration')
         raw_formats = [{'height': 720, 'filesize': (2500*dur*1024)/8}]

    for f in raw_formats:
        h = f.get('height')
        if h and h not in seen:
            file_size = f.get('filesize') or f.get('filesize_approx')
            if not file_size and info.get('duration'):
                est = 1000
                if h >= 720: est = 2500
                file_size = (est * info.get('duration') * 1024) / 8
            
            size_str = formatting.format_size(file_size)
            icon = "📱"
            if h >= 1080: icon = "📺"
            
            qualities.append({'text': f"{icon} {h}p ({size_str})", 'val': h})
            seen.add(h)
    
    qualities.sort(key=lambda x: x['val'], reverse=True)
    
    session_id = str(uuid.uuid4())[:8]
    state.temp_data[session_id] = {'url': url, 'title': title}

    keyboard.append([InlineKeyboardButton("🔥 Auto Quality", callback_data=f"{session_id}|best|Max")])
    row = []
    for q in qualities[:6]:
        row.append(InlineKeyboardButton(q['text'], callback_data=f"{session_id}|{q['val']}|{q['val']}p"))
        if len(row) == 2: keyboard.append(row); row = []
    if row: keyboard.append(row)
    keyboard.append([InlineKeyboardButton("🎧 MP3", callback_data=f"{session_id}|audio|MP3")])

    text_msg = f"🎬 **{title}**\n⏱ `{duration}` | ⚡ `{extractor}`\n👇 **Select Quality:**"
    await msg.edit_text(text_msg, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown")