import os
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
import config
from core import downloader
from utils import state, ui

async def animate_upload(context, chat_id, message_id):
    tick = 0
    percent = 0.0
    try:
        while True:
            if percent < 95: percent += 4.5
            elif percent < 99: percent += 0.5
            text = ui.get_telegram_ul_msg(percent, tick)
            try: await context.bot.edit_message_text(chat_id, message_id, text, parse_mode="Markdown")
            except: pass
            ui.print_termux_upload(percent)
            tick += 1
            await asyncio.sleep(0.8)
    except asyncio.CancelledError:
        try:
             ui.print_termux_upload(100.0)
             await context.bot.edit_message_text(chat_id, message_id, "✅ **Done!**", parse_mode="Markdown")
        except: pass

async def handle_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    data = query.data.split("|")
    session_id, format_req, q_text = data[0], data[1], data[2]
    
    session = state.temp_data.get(session_id)
    if not session: 
        await query.edit_message_text("❌ Session Expired.")
        return

    chat_id = update.effective_chat.id
    msg_id = query.message.message_id
    main_loop = asyncio.get_running_loop()
    
    # تحديد نوع الملف
    is_image = False
    if 'image' in format_req or q_text == 'Photo':
        ext = 'jpg'
        is_image = True
    elif format_req == 'audio':
        ext = 'mp3'
    else:
        ext = 'mp4'
    
    filename = os.path.join(config.DOWNLOADS_DIR, f"v_{session_id}.{ext}")
    
    # فحص هل لدينا رابط مباشر؟
    is_direct = False
    target_url = session['url']
    if session_id in state.direct_links and format_req in state.direct_links[session_id]:
        target_url = state.direct_links[session_id][format_req]
        is_direct = True

    hook = downloader.create_telegram_hook(context, chat_id, msg_id, session_id, main_loop, state.last_update_time)

    try:
        await query.edit_message_text(ui.get_startup_msg(), parse_mode="Markdown")
        
        # تحميل
        await downloader.download_video(target_url, filename, format_req, hook, main_loop, is_direct)
        
        final_file = filename
        if not os.path.exists(final_file):
            base = os.path.splitext(os.path.basename(filename))[0]
            for f in os.listdir(config.DOWNLOADS_DIR):
                if f.startswith(base):
                    final_file = os.path.join(config.DOWNLOADS_DIR, f)
                    break
        
        if final_file and os.path.exists(final_file):
            animation_task = asyncio.create_task(animate_upload(context, chat_id, msg_id))
            try:
                final_title = session['title']
                
                with open(final_file, 'rb') as f:
                    caption = f"🎬 **{final_title}**\n🤖 **By:** MegaBot"
                    
                    if is_image:
                        await context.bot.send_photo(chat_id=chat_id, photo=f, caption=caption, read_timeout=60)
                    elif format_req == 'audio':
                        await context.bot.send_audio(chat_id=chat_id, audio=f, title=final_title, caption=caption, read_timeout=3600)
                    else:
                        await context.bot.send_video(chat_id=chat_id, video=f, caption=caption, supports_streaming=True, read_timeout=3600)
            finally:
                animation_task.cancel()
                await query.delete_message()
                try: os.remove(final_file)
                except: pass
        else:
            await query.edit_message_text("❌ Error: Download failed.")

    except Exception as e:
        try: await query.edit_message_text(f"❌ Error: {str(e)[:100]}")
        except: pass